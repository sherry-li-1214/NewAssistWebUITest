package com.emc.webautomation.pageobjects;

import org.testng.annotations.Test;
import com.emc.webautomation.pageobjects.PageBase;

public class PageEnquerySuccess extends PageBase{
  @Test
  public void f() {
  }
}
