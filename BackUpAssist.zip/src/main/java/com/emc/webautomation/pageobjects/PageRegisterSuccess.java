package com.emc.webautomation.pageobjects;

import com.emc.webautomation.pageobjects.PageBase;

public class PageRegisterSuccess extends PageBase{
	public final static String URL="http://";

}
