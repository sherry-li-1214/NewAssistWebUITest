/**
 * 
 */
package com.emc.webautomation.Enum;

/**
 * @author lis26
 *
 */

public enum BrowserType {
  IE,FIREFOX,CHROME
 }
